 # _Charles Leclerc_

 1. Moanacoi származású.
 + Formula1 autóversenyző a ferrari csapatában.
 ---

[Wikipédia oldal](https://hu.wikipedia.org/wiki/Charles_Leclerc_(aut%C3%B3versenyz%C5%91))

Kép róla ![alt text]( letöltés.jpg )

[^1]: Kedvenc versenyzőm.
> Hétvégén verseeny!!