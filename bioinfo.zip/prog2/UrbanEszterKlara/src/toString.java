package org.example;

public class toString {
    /*
    //Szenzor
    @Override
    public String toString() {
        return String.format("%s (%d; %d)",
                isAktiv() ? "On" : "Off",
                pozicio.getX(), pozicio.getY());
    }
    //Mikrofon
    @Override
    public String toString() {
        return String.format("Mikrofon: %s, Formatum: %s",
                super.toString(), formatum);
    }

    //FenySzenzor
    @Override
    public String toString() {s
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("H:mm");
        return String.format("Feny szenzor: %s, K:%s - Ny:%s",
                super.toString(), napKelte.format(formatter), napNyugta.format(formatter));
    }
     */
}