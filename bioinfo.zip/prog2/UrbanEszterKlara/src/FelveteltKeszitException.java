public class FelveteltKeszitException extends RuntimeException{
    public FelveteltKeszitException(){
    }
}
