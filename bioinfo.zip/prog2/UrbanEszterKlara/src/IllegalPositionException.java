public class IllegalPositionException extends RuntimeException {
    public IllegalPositionException(){}
}
