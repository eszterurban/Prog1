enum Hangformatum
{ MP3, FLAC, AAC }
