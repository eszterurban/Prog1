package teszt;

public class NincsDínóException extends Exception{
    public NincsDínóException (String message){
        super(message);
    }
}
