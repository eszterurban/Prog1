package vendeglatas;

public class NincsElégPiaException extends Exception{
    public NincsElégPiaException(String message) {
        super(message);
    }
}
