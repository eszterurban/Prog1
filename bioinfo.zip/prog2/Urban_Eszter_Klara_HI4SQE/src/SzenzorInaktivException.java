public class SzenzorInaktivException extends RuntimeException {
    public SzenzorInaktivException() {
    }
}