import java.util.*;

public class SzenzorHalozat implements Iterable<Szenzor>{
    private List<Szenzor> szenzorList = new ArrayList<>();


    void telepit(Szenzor szenzor){
        szenzorList.add(szenzor);
    }

    List<Szenzor> aktivSzenzorok() throws CloneNotSupportedException {
        List<Szenzor> aktivSzenzorList = new ArrayList<>();
        for (var e : szenzorList){
            if (e.isAktiv()){
                aktivSzenzorList.add((Szenzor) e.clone());
            }
        }
        return aktivSzenzorList;
    }

    @Override
    public Iterator<Szenzor> iterator() {
        List<Szenzor> aktiv;
        try {
            aktiv = aktivSzenzorok();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }
        Collections.reverse(aktiv);
        return aktiv.iterator();
    }
}
