public class toString {
    /*
    //Szenzor
    @Override
    public String toString() {
        return String.format("%s (%d; %d)",
                isAktiv() ? "On" : "Off",
                pozicio.getX(), pozicio.getY());
    }
    //Kamera
    @Override
    public String toString() {
        return String.format("Kamera: %s, Formátum: %s",
                super.toString(), formatum);
    }

    //Homero
    @Override
    public String toString() {
        return String.format("Hőmérő: %s, A:%d - F:%d",
                super.toString(), alsoHatar, felsoHatar);
    }
     */
}