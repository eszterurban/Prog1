public interface IHomero {
    double homersekletetMer();

    void hatarokatBeallit(int alsoHatar, int felsoHatar);
}