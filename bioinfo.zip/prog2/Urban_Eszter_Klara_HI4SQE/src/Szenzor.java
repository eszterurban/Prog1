public abstract class Szenzor {
    private Pozicio pozicio;

    public Pozicio getPozicio() {
        return pozicio;
    }

    protected void setPozicio(Pozicio pozicio) {
        this.pozicio = pozicio;
    }

    public Szenzor(Pozicio pozicio) {
        this.pozicio = pozicio;
    }

    public abstract boolean isAktiv();

    abstract void adatkuldes();

    @Override
    protected abstract Object clone() throws CloneNotSupportedException;

    @Override
    public String toString() {
        return String.format("%s (%d; %d)",
                isAktiv() ? "On" : "Off",
                pozicio.getX(), pozicio.getY());
    }

}

