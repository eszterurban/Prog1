import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class Kamera extends Szenzor implements IKamera{

    private Kepformatum formatum;



    public Kamera(int x, int y, Kepformatum kepformatum) {
        super(new Pozicio(x, y));
        this.formatum = kepformatum;
    }

    @Override
    public String kepetKeszit() throws SzenzorInaktivException {
        if (!isAktiv()){
            throw new SzenzorInaktivException();
        } else {
            return LocalDate.now() + "_" + LocalTime.now() + "_x" + super.getPozicio().getX() + "_y" + super.getPozicio().getY() + "." + formatum;
        }
    }

    @Override
    public Kepformatum getFormatum() {
        return null;
    }

    @Override
    public boolean isAktiv() {
        if (LocalTime.now().isAfter(LocalTime.of(7,00)) && LocalTime.now().isBefore(LocalTime.of(21,00))){
            return true;
        } else {
            return false;
        }
    }

    @Override
    void adatkuldes() {
        System.out.println("Kép mentve: " + kepetKeszit());
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return new Kamera(super.getPozicio().getX(), super.getPozicio().getY(), formatum);
    }

    @Override
    public String toString() {
        return String.format("Kamera: %s, Formátum: %s",
                super.toString(), formatum);
    }
}

