public class AlacsonyAlsoHatarException extends RuntimeException {
    public AlacsonyAlsoHatarException() {
    }
}
