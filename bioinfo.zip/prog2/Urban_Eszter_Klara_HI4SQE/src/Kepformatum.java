enum Kepformatum
{ PNG, JPEG, BMP, RAW }
