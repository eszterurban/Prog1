import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Random;

public class Homero extends Szenzor implements IHomero{

    private int alsoHatar;
    private int felsoHatar;
    private boolean aktiv;

    public int getAlsoHatar() {
        return alsoHatar;
    }

    private void setAlsoHatar(int alsoHatar) {
        if (this.alsoHatar < -60)
        {
            throw new AlacsonyAlsoHatarException();
        } else {
            this.alsoHatar = alsoHatar;
        }
    }

    public int getFelsoHatar() {
        return felsoHatar;
    }

    private void setFelsoHatar(int felsoHatar) {
        this.felsoHatar = felsoHatar;
    }

    public void setAktiv(boolean aktiv) {
        this.aktiv = aktiv;
    }

    public Homero(int x, int y, int alsoHatar, int felsoHatar) {
        super(new Pozicio(x, y));
        hatarokatBeallit(alsoHatar, felsoHatar);
        aktiv = true;
    }

    @Override
    public double homersekletetMer() {
        if (!aktiv){
            throw new SzenzorInaktivException();
        } else {
            Random rnd = new Random();
            double random = rnd.nextDouble(alsoHatar, felsoHatar);
            DecimalFormat df = new DecimalFormat("0.00");
            return Double.parseDouble(df.format(random));
        }
    }

    @Override
    public void hatarokatBeallit(int alsoHatar, int felsoHatar) {
        this.setAlsoHatar(alsoHatar);
        this.setFelsoHatar(felsoHatar);
    }

    @Override
    public boolean isAktiv() {
        return aktiv;
    }

    @Override
    void adatkuldes() {
        System.out.println("Hőmérséklet a(z) (" + super.getPozicio().getX() + ";" + super.getPozicio().getY() + ") pozíción "
                + LocalDate.now() + " " + LocalTime.now() + " időpontban: " + homersekletetMer() + "°C");
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return new Homero(super.getPozicio().getX(), super.getPozicio().getY(), this.alsoHatar, this.felsoHatar);
    }

    @Override
    public String toString() {
        return String.format("Hőmérő: %s, A:%d - F:%d",
                super.toString(), alsoHatar, felsoHatar);
    }
}
