public interface IKamera {
    String kepetKeszit() throws SzenzorInaktivException;

    Kepformatum getFormatum();
}

